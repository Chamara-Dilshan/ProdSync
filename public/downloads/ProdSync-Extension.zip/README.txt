================================================================================
  ProdSync Chrome Extension - Installation Guide
================================================================================

Thank you for downloading the ProdSync Chrome Extension!

This extension helps you generate AI-powered replies to Etsy buyer messages
directly on the Etsy website.

================================================================================
  INSTALLATION STEPS
================================================================================

1. EXTRACT THIS ZIP FILE
   - Extract all files to a folder on your computer
   - Remember the location of this folder!

2. OPEN CHROME EXTENSIONS PAGE
   - Open Google Chrome
   - Go to: chrome://extensions/
   - Or: Click menu (⋮) → Extensions → Manage Extensions

3. ENABLE DEVELOPER MODE
   - Toggle "Developer mode" switch in the top-right corner
   - This allows you to install unpacked extensions

4. LOAD THE EXTENSION
   - Click "Load unpacked" button
   - Select THIS FOLDER (the one containing these files)
   - The ProdSync extension should now appear in your extensions list

5. PIN THE EXTENSION (Optional but recommended)
   - Click the puzzle icon (🧩) in Chrome toolbar
   - Find ProdSync and click the pin icon
   - This makes it easier to access

================================================================================
  HOW TO USE
================================================================================

1. SIGN IN TO YOUR PRODSYNC ACCOUNT
   - Click the ProdSync extension icon in Chrome toolbar
   - Sign in with your ProdSync account credentials

2. CONFIGURE YOUR SETTINGS
   - Go to ProdSync web app: http://localhost:3000 (or your deployed URL)
   - Navigate to Settings page
   - Add your AI provider API key (OpenAI, Google Gemini, or Anthropic)
   - (Optional) Add products and policies for better AI responses

3. USE ON ETSY
   - Visit: https://www.etsy.com/messages
   - Open any buyer conversation
   - Look for the "✨ Generate Reply with ProdSync" button
   - Click it to generate an AI-powered reply
   - Review, edit if needed, and send!

================================================================================
  REQUIREMENTS
================================================================================

- Google Chrome (Version 88 or higher)
- ProdSync account (sign up at your ProdSync web app)
- AI provider API key (configured in ProdSync Settings)
- Active Etsy seller account

================================================================================
  TROUBLESHOOTING
================================================================================

Extension not loading?
  → Make sure you selected the correct folder (containing manifest.json)
  → Check that Developer mode is enabled
  → Try reloading the extension from chrome://extensions/

Button not appearing on Etsy?
  → Make sure you're on www.etsy.com/messages
  → Refresh the Etsy page
  → Check browser console (F12) for any errors

Can't generate replies?
  → Make sure you've configured an API key in ProdSync Settings
  → Check that your API key is valid and has credits/quota
  → Sign out and sign back in to the extension

================================================================================
  SUPPORT
================================================================================

For more help, visit:
- Full Documentation: Check CLAUDE.md in the project repository
- Extension Guide: /dashboard/extension page in ProdSync web app

================================================================================
  COPYRIGHT
================================================================================

© 2026 Chamara Dilshan & ProdSync
Built for Etsy sellers.

================================================================================
